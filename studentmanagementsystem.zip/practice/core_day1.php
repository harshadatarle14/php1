<?php
#Array
 $arr =[1,2,2,3,4,4,5];
 $unique = array_unique($arr);
 $sum= array_sum($unique);
 echo "The array list is: " ;
 print_r($arr);  //to print array print_r/var_dump is used
 echo "<br>";
 echo "To remove duplicate : " ;
 var_dump($unique);
 echo "<br>";
 echo "The sum of unique value : " ;
 var_dump($sum);

 #String
 echo "<br>";
 $str = "     Nagpur Machine Test";
 echo "The string is: ".$str;
 echo "<br>";
echo "The string trim is:";
 echo trim($str);
 echo "<br> the String word is:  ";
 echo str_word_count($str);

 #Function +Datatype
  
 function checkType($var){
     if(is_int($var)){
        echo "<br>";
        echo "int";
     }
     elseif(is_float($var)){
        echo "<br>";
        echo "float";
     }
     elseif (is_string($var)){
        echo "<br>";
        echo "String";
     }
     elseif(is_array($var)){
        echo "<br>";
        // echo "Array";
        print_r($var);
     }
     else{
        echo "<br>";
        echo gettype($var);
     }
 }
 echo checkType(45);
 echo checkType("the string");
 echo checkType([1,2,3,8,9]);
echo checkType(57.9);

#Operetor + statement
for ($i=1; $i <=100;$i++){
    if ($i%3==0 && $i % 5==0){
         echo "<br>";
        echo "FizzBuzz";
    }
    elseif($i%3==0) {
         echo "<br>";
        echo "Fizz";
    }
    elseif ($i% 5 == 0) {
         echo "<br>";
        echo "Buzz";
    }
    else{
         echo "<br>";
        echo $i;
    }
}
?>