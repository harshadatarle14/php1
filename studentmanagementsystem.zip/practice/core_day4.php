<?php

 if (isset($_GET['submit'])) {
    if (empty($_GET['name'])) {
        echo "Please enter a name";
    }
    else {  
        $name = $_GET['name'];
        echo "Hello via GET, $name";
     }
    }   
    $conn = mysqli_connect("localhost","root","","test");
    if ($conn) {
        echo "<br> Connected successfully";
    } else {
        echo "Failed: " .mysqli_connect_error();
    }
    echo "<br>";

?>
<form action="" method="get">
    Name: <input type="text" name="name" id="" placeholder="Enter your name ">
            <input type="submit" name="submit" value="Submit">
</form>