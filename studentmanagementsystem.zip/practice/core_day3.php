<?php
#array
 $student = ["name"=>"Amit", "age"=>21, "city"=>"Nagpur" , "marks"=>85];
 foreach ($student as $key => $value) {
    echo $key. " : ".$value ."<br>"; 
    }

    #Function#
    function calculateTotal($price,$qty){
        $var =$price*$qty;
        // echo $price ."<br>" .$qty;
        echo "<br> the variable is: ".$var;
    }
    calculateTotal(100,3);

    #String function#
    $string = "  php is Awesome   ";
    echo "<br> The Given String is: ".$string;
    $trim =trim($string);
    echo "<br> the string length is: ".strlen($trim);
    echo "<br> the Uppercase : ".strtoupper($trim);   
    echo "<br> to check the awesome word in list: " .strpos($string, "Awesome");

    #Form#
    
?>