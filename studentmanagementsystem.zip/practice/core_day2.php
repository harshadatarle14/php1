<?php
 $arr =[2,2,3,4,4,5,5,6];
 echo "The Array list is : ";
 print_r($arr);
 echo "<br>";
 $duplicate= array_unique($arr);
 echo "To remove duplicate  : ";
 print_r ($duplicate);
 echo "<br>"; 
 $evensum=0;
 foreach ($duplicate as $num) {
    if ($num % 2 == 0) {
        $evensum = $evensum + $num; 
    }
 }
 echo "even sum is: ";
 echo $evensum;

 #String #

 $str = "   hello world php   ";
 echo "<br> this is given string:  ".$str;
 echo "<br> This is trim String:  " ;
 $trim= trim($str);
 echo $trim;
 echo "<br> The word in string: ".str_word_count($trim);
 echo "<br> The string is reversed: ".strrev($trim);

 #Function#

 function checkValue($a) {
    if ($a<0) {
       echo "<br>";
       echo "Negative".$a;
    } elseif ($a==0) {
        echo "<br>";
        echo "Zero".$a;
    } elseif($a>0){
        echo "<br>";
        echo "Positive".$a;
    } else {
        echo "<br>".$a;
    }
 }
 checkValue(9);
 checkValue(0);
 checkValue(-2);

 #Loop#
 for ($i=1; $i <=50 ; $i++) {

    if ($i%5==0 && $i%7==0){
        echo "<br> Buzzjazz" .$i;
    }
    elseif ($i%5==0) {
        echo "<br> Buzz-" .$i ;
    } elseif ($i%7==0) {
        echo  "<br> Jazz-" .$i ;
    } else {
        echo "<br>".$i;
    }
 }

?>